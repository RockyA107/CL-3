import Pyro4

def main():
    # Connect using the nameserver instead of reading URI from file
    ns = Pyro4.locateNS()
    uri = ns.lookup("string.concatenation")
    
    server = Pyro4.Proxy(uri)
    
    str1 = input("Enter the first string: ")
    str2 = input("Enter the second string: ")
    
    result = server.concatenate_strings(str1, str2)
    print("Concatenated Result:", result)

if __name__ == "__main__":
    main()