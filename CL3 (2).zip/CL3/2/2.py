# RMI
# Design a distributed application using RMI for remote computation where client submits two strings to the server and server returns the concatenation of the given strings.
# IN PLACE OF RMI WE USE XMLRPC BECAUSE IT SUPPORT PYTHON IT WORK SAME LIKE RMI..

from xmlrpc.server import SimpleXMLRPCServer
import xmlrpc.client
import threading
import time

# Define the server logic
def start_server():
    server = SimpleXMLRPCServer(("localhost", 9000), allow_none=True)
    print("Server is running at localhost:9000")

    # ✅ CHANGED: Renamed function and updated logic to work with strings directly
    def concatenate_strings(str1, str2):
        return str1 + str2  # Simple string concatenation

    # ✅ CHANGED: Register the new string-based function
    server.register_function(concatenate_strings, "concatenate_strings")
    server.serve_forever()

# Start server in background thread
server_thread = threading.Thread(target=start_server, daemon=True)
server_thread.start()

# Let server start up
time.sleep(2)

# Client logic
client = xmlrpc.client.ServerProxy("http://localhost:9000/")

# ✅ CHANGED: Take string input instead of numbers
str1 = input("Enter first string: ")
str2 = input("Enter second string: ")

# ✅ CHANGED: Call the updated function for string concatenation
result = client.concatenate_strings(str1, str2)
print("Concatenated Result:", result)