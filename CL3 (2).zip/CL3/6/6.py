#Title : Implementation of Clonal selection algorithm using Python 

import random 
import numpy as np 

# Define objective function (Sphere function for minimization) 
def objective_function(x): 
    return np.sum(x**2)  # Sphere function (minimization) 

def clonal_selection_algorithm(dimensions, num_candidates, num_clones, mutation_rate, max_iterations):
    # Initialize population randomly
    population = [np.random.uniform(-5, 5, dimensions) for _ in range(num_candidates)]
    
    # Main optimization loop
    for iteration in range(max_iterations): 
        # Evaluate fitness of each candidate solution 
        fitness = [objective_function(candidate) for candidate in population] 
        # Sort candidates by fitness (minimization problem) 
        sorted_indices = np.argsort(fitness) 
        population = [population[i] for i in sorted_indices] 
        fitness = [fitness[i] for i in sorted_indices] 
        
        # Select top candidates for cloning (proportional to fitness) 
        selected_candidates = population[:num_clones] 
        
        # Clone candidates (proportional to their ranking) 
        clones = [] 
        for i, candidate in enumerate(selected_candidates): 
            num_clones_for_candidate = int(num_clones * (1 - i / len(selected_candidates)))  # More clones for better candidates 
            clones.extend([candidate.copy() for _ in range(num_clones_for_candidate)]) 
            
        # Mutate clones 
        for i in range(len(clones)): 
            for j in range(dimensions): 
                if random.random() < mutation_rate: 
                    clones[i][j] += np.random.normal(0, 0.2)  # Gaussian mutation 
                    
        # Evaluate fitness of clones 
        clone_fitness = [objective_function(clone) for clone in clones] 
        
        # Select the best candidates among original and clones (elitism) 
        combined_population = population + clones 
        combined_fitness = fitness + clone_fitness 
        
        # Sort combined population by fitness 
        sorted_indices = np.argsort(combined_fitness) 
        population = [combined_population[i] for i in sorted_indices[:num_candidates]] 
        
        # Output best solution in this iteration 
        print(f"Iteration {iteration + 1}: Best solution - {population[0]}, Fitness - {combined_fitness[sorted_indices[0]]}") 
    
    # Return best solution found 
    best_solution = population[0] 
    best_fitness = objective_function(best_solution) 
    return best_solution, best_fitness 

# Example usage 
if __name__ == "__main__":
    dimensions = 3 
    num_candidates = 20 
    num_clones = 10 
    mutation_rate = 0.1 
    max_iterations = 50 
    
    best_solution, best_fitness = clonal_selection_algorithm(
        dimensions, num_candidates, num_clones, mutation_rate, max_iterations
    ) 
    print("\nFinal Best Solution:", best_solution) 
    print("Final Best Fitness:", best_fitness)