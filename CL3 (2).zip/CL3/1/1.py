#RPC
#Design a distributed application using RPC for remote computation where client submits an integer value to the server and server calculates factorial and returns the result to the client program.

import threading
from xmlrpc.server import SimpleXMLRPCServer
from xmlrpc.server import SimpleXMLRPCRequestHandler
import xmlrpc.client
import time

# Step 1: Define the server-side logic (factserver.py)
class FactorialServer:
    def calculate_factorial(self, n):
        if n < 0:
            raise ValueError("Input must be a non-negative integer.")
        result = 1
        for i in range(1, n + 1):
            result *= i
        return result

class RequestHandler(SimpleXMLRPCRequestHandler):
    rpc_paths = ('/RPC2',)

def run_server():
    with SimpleXMLRPCServer(("localhost", 8000), requestHandler=RequestHandler, logRequests=True, allow_none=True) as server:
        server.register_instance(FactorialServer())
        print("FactorialServer is ready to accept requests.")
        server.serve_forever()

# Step 2: Start the server in a background thread (just like running factserver.py)
server_thread = threading.Thread(target=run_server, daemon=True)
server_thread.start()

# Give it a moment to start up
time.sleep(1)

# Step 3: Simulate running the client (like running client.py)
with xmlrpc.client.ServerProxy("http://localhost:8000/RPC2") as proxy:
    try:
        input_value = 7
        result = proxy.calculate_factorial(input_value)
        print(f"Factorial of {input_value} is: {result}")
    except Exception as e:
        print(f"Error: {e}")